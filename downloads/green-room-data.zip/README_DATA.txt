GREEN ROOM - DATA BUNDLE
========================
games.csv                  one row per ranked game (same numbers as the Call Sheet)
schedule_heatmap.csv       viewers-per-streamer per day x hour. clock=UTC or streamer-local;
                           n = number of distinct snapshots behind the cell, ratio = mean of
                           (viewers / unique streamers) per snapshot. Missing day/hour rows =
                           the collector never ran in that slot.
gpu_monthly.csv           average tracked GPU price per month (USD)
data.json / insights.json  the exact files the website reads
raw_monthly/               monthly source files (parquet): steam, twitch, gpu, game_data

TIME BASIS: snapshot_date/snapshot_time in raw_monthly are Thailand time (Asia/Bangkok, UTC+7).
Subtract 7 hours to get UTC. All UTC day/hour values in the CSVs/JSON are already converted.
